  Build an Laravel 11 CRUD Operation Step by Step example. you have to simply follow the below steps:
  - Step 1: Install Laravel 11
  - Step 2: MySQL Database Configuration
  - Step 3: Create Migration
  - Step 4: Create Form Request Validation Class
  - Step 5: Create Controller and Model
  - Step 6: Add Resource Route
  - Step 7: Update AppServiceProvider
  - Step 8: Add Blade Files
  - Run Laravel 11 App
